@extends('classroom.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
                <h2>Laravel 9 CRUD Example</h2>
        </div>
        <div class="col-lg-1 ">
            <a class="btn btn-success" href="{{ route('classroom.create') }}">Add</a>
        </div>
    </div>
 
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
 
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>
        @php
            $i = 0;
        @endphp
        @foreach ($classrooms as $classroom)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $classroom->name }}</td>
                <td>
                    <form action="{{ route('classroom.destroy',$classroom->id) }}" method="POST">
                        <a class="btn btn-info" href="{{ route('classroom.show',$classroom->id) }}">Show</a>
                        <a class="btn btn-primary" href="{{ route('classroom.edit',$classroom->id) }}">Edit</a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection